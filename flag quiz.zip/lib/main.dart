import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(const FlagQuizApp());
}

class FlagQuizApp extends StatelessWidget {
  const FlagQuizApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flag Quiz Game',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.indigo,
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    emailController.dispose();
    passController.dispose();
    super.dispose();
  }

  void _handleLogin(BuildContext context) {
    if (_formKey.currentState!.validate()) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const QuizPage()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.flag_circle, size: 100, color: Colors.indigo),
                const SizedBox(height: 20),
                const Text(
                  "Flag Quiz",
                  style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 30),
                TextFormField(
                  controller: emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    labelText: 'Email',
                    prefixIcon: const Icon(Icons.email),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'الرجاء إدخال البريد الإلكتروني';
                    }
                    if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                        .hasMatch(value)) {
                      return 'الرجاء إدخال بريد إلكتروني صحيح';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 15),
                TextFormField(
                  controller: passController,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    prefixIcon: const Icon(Icons.lock),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'الرجاء إدخال كلمة المرور';
                    }
                    if (value.length < 6) {
                      return 'يجب أن تكون كلمة المرور 6 أحرف على الأقل';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 25),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.login, color: Colors.white),
                    label: const Text(
                      'Login',
                      style: TextStyle(fontSize: 18, color: Colors.white),
                    ),
                    onPressed: () => _handleLogin(context),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.indigo,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class QuizPage extends StatefulWidget {
  const QuizPage({super.key});

  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  final List<Map<String, String>> flags = [
    {'image': 'https://flagcdn.com/w320/fr.png', 'country': 'France'},
    {'image': 'https://flagcdn.com/w320/de.png', 'country': 'Germany'},
    {'image': 'https://flagcdn.com/w320/jp.png', 'country': 'Japan'},
    {'image': 'https://flagcdn.com/w320/eg.png', 'country': 'Egypt'},
    {'image': 'https://flagcdn.com/w320/br.png', 'country': 'Brazil'},
    {'image': 'https://flagcdn.com/w320/it.png', 'country': 'Italy'},
    {'image': 'https://flagcdn.com/w320/us.png', 'country': 'USA'},
    {'image': 'https://flagcdn.com/w320/sa.png', 'country': 'Saudi Arabia'},
    {'image': 'https://flagcdn.com/w320/cn.png', 'country': 'China'},
    {'image': 'https://flagcdn.com/w320/ca.png', 'country': 'Canada'},
    {'image': 'https://flagcdn.com/w320/tr.png', 'country': 'Turkey'},
  ];

  int currentIndex = 0;
  int score = 0;
  List<String> options = [];
  final Random random = Random();

  @override
  void initState() {
    super.initState();
    generateOptions();
  }

  void generateOptions() {
    final correctCountry = flags[currentIndex]['country']!;
    options = [correctCountry];
    while (options.length < 4) {
      String randomCountry = flags[random.nextInt(flags.length)]['country']!;
      if (!options.contains(randomCountry)) {
        options.add(randomCountry);
      }
    }
    options.shuffle();
  }

  void checkAnswer(String selected) {
    bool isCorrect = selected == flags[currentIndex]['country'];
    if (isCorrect) score++;
    nextQuestion();
  }

  void nextQuestion() {
    if (currentIndex + 1 >= flags.length) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => CongratsScreen(score: score, total: flags.length),
        ),
      );
    } else {
      setState(() {
        currentIndex++;
        generateOptions();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentFlag = flags[currentIndex];
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flag Quiz'),
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Text(
              'اختر اسم الدولة لهذا العلم:',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 25),
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.network(
                currentFlag['image']!,
                height: 180,
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    height: 180,
                    color: Colors.grey[300],
                    child: const Center(child: Text('خطأ في تحميل الصورة')),
                  );
                },
              ),
            ),
            const SizedBox(height: 30),
            ...options.map((option) {
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => checkAnswer(option),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    backgroundColor: Colors.indigoAccent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    option,
                    style: const TextStyle(fontSize: 18, color: Colors.white),
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}

class CongratsScreen extends StatelessWidget {
  final int score;
  final int total;

  const CongratsScreen({super.key, required this.score, required this.total});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.indigo.shade50,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.emoji_events, color: Colors.amber, size: 100),
              const SizedBox(height: 20),
              const Text(
                "مبروك!",
                style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              Text(
                " 👏 لقد قمت بالأجابة علي $score من $total ",
                style: const TextStyle(fontSize: 20),
              ),
              const SizedBox(height: 30),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (_) => const QuizPage()),
                  );
                },
                icon: const Icon(Icons.restart_alt, color: Colors.white),
                label: const Text(
                  "إعادة اللعب",
                  style: TextStyle(fontSize: 18, color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.indigo,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 15),
              TextButton(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (_) => const LoginPage()),
                  );
                },
                child: const Text(
                  "تسجيل الخروج",
                  style: TextStyle(fontSize: 16, color: Colors.indigo),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
